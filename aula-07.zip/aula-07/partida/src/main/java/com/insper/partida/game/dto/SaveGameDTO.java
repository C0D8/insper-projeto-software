package com.insper.partida.game.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SaveGameDTO {
    private String home;
    private String away;
}
