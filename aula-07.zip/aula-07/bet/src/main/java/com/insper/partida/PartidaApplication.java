package com.insper.partida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PartidaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PartidaApplication.class, args);
	}

}
