package com.insper.partida.game;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TeamReturnDTO {
    private String identifier;
    private String name;
}
