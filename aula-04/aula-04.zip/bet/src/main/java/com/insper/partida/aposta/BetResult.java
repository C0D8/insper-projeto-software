package com.insper.partida.aposta;

public enum BetResult {
    HOME, AWAY, DRAW
}
